<h3>Name: <?php echo $contact_name;?></h3>
<span>Email: <?php echo $contact_email;?></span>
<br/>
<span>Phone : <?php echo $contact_phone;?></span>
<br/>
<span> Country: <?php echo $contact_country;?> </span>
<br/>
------------------------- <br /><br />
<span> Message: <?php echo $contact_message;?> </span>
<br/>
---------------------<br /><br />
Regards <?php echo $contact_name;?>
