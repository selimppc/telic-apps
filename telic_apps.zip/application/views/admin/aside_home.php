Quick Menu :: 

<ul>
    <li><a href="<?php echo base_url();?>super_admin/add_category_form">Add Category</a> </li>
    <li><a href="<?php echo base_url();?>super_admin/add_content_form">Add Content</a></li>
    <li><a href="<?php echo base_url();?>super_admin/add_gallery_form">Add Gallery</a></li>

</ul>

Sidebar :: 

<ul>
    <li><a href="<?php echo base_url();?>super_admin/about_me">About Me</a> </li>

</ul>

Theme Options :: 

<ul>
    <li><a href="<?php echo base_url();?>super_admin/add_logo">Logo (Theme) </a> </li>

</ul>

Footer :: 

<ul>
    <li><a href="">Footer Left</a> </li>
    <li><a href="">Footer MIddle</a></li>
    <li><a href=""> Footer Right</a></li>
</ul>