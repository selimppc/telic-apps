<h1> Dashboard </h1>
<div id="content_area">
    <span style="color: #006699; font-size: 20px; line-height: 30px; border-bottom: 1px solid #ccc;">
        Welcome to my Apps Center. Here you may control the application fully. <br/> <br/> <br/>
    </span>
    
    <span style="color: #006699; font-size: 13px; line-height: 22px; ">
        For More details ::: <br/><br/>
        
        Selim Reza<br/>
        Cell: (183)180-3255<br/>
        Email: selimppc@gmail.com<br/>
        
        
    </span>
</div>